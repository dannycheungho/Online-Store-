<?php

require_once(dirname(__FILE__) . '/../vendor/autoload.php');

$chatkit = new Chatkit\Chatkit([
  'instance_locator' => 'v1:us1:1fb82e6e-d3b8-4e97-be5b-f98b8a522aea',
  'key' => 'f0b9a017-e6b8-4370-9cab-4c4228837abb:bD+OQwo9KZzuoWbgQh8DOoOz329+ln29jrhz5+rMQGQ='
]);

print_r($chatkit->addUsersToRoom([
  'room_id' => 'A BIG ROOM',
  'user_ids' => ['ham2', 'phptest']
]));
