<?php

namespace Chatkit\Exceptions;

use Exception;

class MissingArgumentException extends Exception
{
}
