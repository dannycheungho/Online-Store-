<?php

namespace Chatkit\Exceptions;

use Exception;

class ConnectionException extends Exception
{
}
