<?php

namespace Chatkit\Exceptions;

use Exception;

class ConfigurationException extends Exception
{
}
