<?php

namespace Chatkit\Exceptions;

use Exception;

class TypeMismatchException extends Exception
{
}
