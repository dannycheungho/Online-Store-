<?php
session_start();
include_once('config.php');
$id = "";
try {
	if ( isset ( $_POST['user_id'] ) ) { 
	$id =  $_POST['user_id'];
	$chatkit->createUser([
	  'id' => $id,
	  'name' => $id,
	  'avatar_url' => 'https://placekitten.com/400/500',
	]);
	 
	$_SESSION['userid'] = $id;
	
	}
}
catch (exception $e) {
	echo "Username already use";
}
?>