<?php
include_once('config.php');




print_r($chatkit->createRoom([
  'creator_id' => 'ham',
  'name' => 'YAYA',
  'private' => false
]));
